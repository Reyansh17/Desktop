import React from 'react';
import './Marquee.css'; // Create this file in the same directory as your component

const Marquee = () => {
  return (
    <div className="marquee-container">
    
      <div className="marquee-text">
      📢 Stay tuned for exciting updates and upcoming events! 
      </div>
      <div className="marquee-text">
      Join us on a journey of innovation and knowledge. 🚀
      </div>
      <div className="marquee-text">
      Iete
      </div>
    </div>
  );
}

export default Marquee;